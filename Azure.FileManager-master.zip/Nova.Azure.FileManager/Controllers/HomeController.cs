﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Azure;
using Kendo.Mvc.UI;
using Nova.Azure.FileManager.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using Microsoft.Ajax.Utilities;
using System.Runtime.InteropServices.ComTypes;
using System.Net.Mail;
using System.Configuration;
using RestSharp;
using System.DirectoryServices;
using System.Windows.Forms;
using System.Threading;
using System.Web.Hosting;
using System.Globalization;

namespace Nova.Azure.FileManager.Controllers
{
    public class HomeController : Controller
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static cUser CurrentUser = new cUser();
        private readonly FileContentBrowser directoryBrowser;
        public static IEnumerable<FileManagerEntry> fMgrEntries = new List<FileManagerEntry>();

        public HomeController()
        {
            // Helper utility for the FileManager controller
            directoryBrowser = new FileContentBrowser();
        }

        [Authorize]
        public ActionResult Index()
        {

            GetCurrentUser();

            _log.Info(CurrentUser.UserName);
            
            return View(CurrentUser);

        }

        public ActionResult Help()
        {
            GetCurrentUser();
            return View();
        }

        public void GetCurrentUser()
        {
            string isTest = ConfigurationManager.AppSettings["isTest"].ToString();
            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
            if (isTest == "true" && User.Identity.Name.ToLower().Contains("groff") || User.Identity.Name.ToLower().Contains("earp"))
            {
                CurrentUser.UserID = ConfigurationManager.AppSettings["testuser"].ToString();
                CurrentUser.UserName = CurrentUser.UserID.Replace("NOVA\\", "").Replace("."," ");
                //CurrentUser.UserRole = getUserInfo(CurrentUser.UserID); // "LO";
                CurrentUser.UserEmail = String.Concat(CurrentUser.UserID.Replace("NOVA\\", ""), "@novahomeloans.com");
            }
            else if (User.Identity.Name.ToLower().Contains("groff"))
            {
                CurrentUser.UserName = User.Identity.Name.Replace("NOVA\\", "").Replace(".", " ");
                CurrentUser.UserID = User.Identity.Name;
                CurrentUser.UserRole = "Admin";
                CurrentUser.UserEmail = String.Concat(User.Identity.Name.Replace("NOVA\\", ""), "@novahomeloans.com");
            }
            else
            {
                CurrentUser.UserID = User.Identity.Name;
                CurrentUser.UserName = User.Identity.Name.Replace("NOVA\\", "").Replace(".", " "); 
                CurrentUser.UserEmail = String.Concat(User.Identity.Name.Replace("NOVA\\", ""), "@novahomeloans.com");
                //CurrentUser.UserRole= getUserInfo(CurrentUser.UserID);
            }

            if (CurrentUser.UserName.ToLower() == "amelia.olvera")
            {
                CurrentUser.UserName = "Amelia C Olvera";
                CurrentUser.UserRole = "Senior Loan Officer";
            }
            else if (CurrentUser.UserName.ToLower() == "margaret.roman")
            {
                CurrentUser.UserName = "Margaret Borquez";
                CurrentUser.UserRole = "Loan Officer Associate";
            }
            else if (CurrentUser.UserName.ToLower() == "lyn.cooley")
            {
                CurrentUser.UserName = "Raquel Cooley";
                CurrentUser.UserRole = "Loan Officer";
            }

            //string uRole = getUserInfo(CurrentUser.UserID);

            CurrentUser.UserName=textInfo.ToTitleCase(CurrentUser.UserName);
        }

        // GET: FileManagerData
        private string ToAbsolute(string virtualPath)
        {
            return VirtualPathUtility.ToAbsolute(virtualPath);
        }

        public string ContentPath
        {
            get
            {
                return "~/";
            }
        }

        private string CombinePaths(string basePath, string relativePath)
        {
            return VirtualPathUtility.Combine(VirtualPathUtility.AppendTrailingSlash(basePath), relativePath);
        }

        public string NormalizePath(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return ToAbsolute(ContentPath);
            }

            return CombinePaths(ToAbsolute(ContentPath), path);
        }

        public FileManagerEntry VirtualizePath(FileManagerEntry entry)
        {
            entry.Path = entry.Path.Replace(Server.MapPath(ContentPath), "").Replace(@"\", "/");
            return entry;
        }

        [HttpPost]
        public JsonResult Read(string target)
        {
            //GetCurrentUser();
            string blobContainer = string.Empty;
            try
            {
                var path = NormalizePath(target);

                blobContainer = CurrentUser.UserID.Replace("NOVA\\", "").Replace(".","");

                string blobCon = "blobconnectionstring";
                BlobServiceClient bSC = new BlobServiceClient(blobCon);

                var container = bSC.GetBlobContainerClient(blobContainer.ToLower());  //  "tpopublicfiles"

                if (!container.Exists())
                {
                    bSC.CreateBlobContainer(blobContainer.ToLower());
                }

                List<FileManagerEntry> fmes = new List<FileManagerEntry>();
                directoryBrowser.Server = Server;

                var result = directoryBrowser.GetFiles(container, target).Concat(directoryBrowser.GetDirectories(container, target)).Select(VirtualizePath);
                return Json(result, JsonRequestBehavior.AllowGet);
            } catch (Exception ex) 
            { 
                _log.Error("Error in Home.Read: " + ex.Message + ";" + blobContainer);
                return Json(null, JsonRequestBehavior.AllowGet);
            }

        }

        [HttpGet]
        public FileResult Download(string path)
        {
            //GetCurrentUser();
            byte[] readStream = null;
            string contentType = MimeMapping.GetMimeMapping(path);
            string localFilePath = string.Empty;

            try
            {
                string[] pth=path.Split('/');
                string lPath = "~/Content/UserFiles/"; // "C:\\UserFiles\\";
                var virtualPath = lPath + "\\" + path;
                if (pth.Length > 1)
                {
                    lPath="~/Content/UserFiles/" + pth[0] + "/";
                    virtualPath = lPath + pth[1];
                    localFilePath = HostingEnvironment.MapPath(virtualPath);  //lPath + "\\" + path;  
                    if (!Directory.Exists(localFilePath.Replace(pth[1], "")))
                    {
                        Directory.CreateDirectory(localFilePath.Replace(pth[1], ""));
                    }
                } else
                {
                    localFilePath = HostingEnvironment.MapPath(virtualPath);
                }

                string blobContainer = CurrentUser.UserID.Replace("NOVA\\", "").Replace(".", "").ToLower();

                string blobCon = "blobconnectionstring";

                BlobContainerClient container = new BlobContainerClient(blobCon, blobContainer);  // "tpopublicfiles"  

                BlobClient client = container.GetBlobClient(path);
            
                client.DownloadTo(localFilePath);

                //contentType= MimeMapping.GetMimeMapping(path);
                readStream = System.IO.File.ReadAllBytes(localFilePath);
                return File(readStream, contentType);
            } catch (Exception ex)
            {
                _log.Error("Error saving file:" + ex.Message + "\r\n\t" + contentType);
                return File(readStream, contentType);
            }
        }

        public ActionResult Destroy(FileManagerEntry entry)
        {
            //GetCurrentUser();
            var path = NormalizePath(entry.Path);
            try
            {
                if (!string.IsNullOrEmpty(path))
                {
                    string blobContainer = CurrentUser.UserID.Replace("NOVA\\", "").Replace(".", "").ToLower();

                    string blobCon = "blobconnectionstring";
                    BlobServiceClient bSC = new BlobServiceClient(blobCon);

                    var container = bSC.GetBlobContainerClient(blobContainer);
                    BlobClient blobClient = container.GetBlobClient(entry.Path);

                    blobClient.Delete();

                    return Json(new object[0]);
                }

                throw new HttpException(404, "File Not Found");
            }
            catch (Exception ex)
            {
                _log.Error("Error in Home.Destroy: " + ex.Message);
                return Json(new object[0]);
            }
            
        }


        /// <summary>
        /// Uploads a file to a given path.
        /// </summary>
        /// <param name="path">The path to which the file should be uploaded.</param>
        /// <param name="file">The file which should be uploaded.</param>
        /// <returns>A <see cref="JsonResult"/> containing the uploaded file's size and name.</returns>
        /// <exception cref="HttpException">Forbidden</exception>
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Upload(string path, HttpPostedFileBase file)
        {
            //GetCurrentUser();

            string blobContainer = string.Empty;

            try
            {
                blobContainer = CurrentUser.UserID.Replace("NOVA\\", "").Replace(".", "").ToLower();
                path = NormalizePath(path);
                var fileName = Path.GetFileName(file.FileName);

                if (!string.IsNullOrEmpty(path))
                {
                    fileName = path + fileName;
                }

                string blobCon = "blobconnectionstring";
                BlobServiceClient bSC = new BlobServiceClient(blobCon);

                var container = bSC.GetBlobContainerClient(blobContainer);
                BlobClient blobClient = container.GetBlobClient(fileName);

                blobClient.Upload(file.InputStream, true);

                var result = directoryBrowser.GetFiles(container, null).Select(VirtualizePath);
                return Json(result, JsonRequestBehavior.AllowGet);
            } catch (Exception ex)
            {
                _log.Error("Error in Home.Upload: " +  ex.Message);
                return Json(null, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult SendLink(string loannumber, string email, string LO, string loEmail, string role)
        {
            //GetCurrentUser();

            Borrower borr = getLoanInfo(loannumber);

            try
            {
                string baseURL = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath;
                //string link = baseURL + "borrFileMgrData/borrIndex?loanNbr=" + loannumber + "&LO=" + LO; 
                string link = baseURL + "borrFileMgrData/borrIndex?loanNbr=" + loannumber + "&LO=" + CurrentUser.UserID.Replace("NOVA\\", "").Replace(".", "").ToLower(); 

                MailMessage msg = new MailMessage();
                msg.From = new MailAddress(loEmail);

                msg.Subject = "Document uploads needed";
                msg.IsBodyHtml = true;
                if (!string.IsNullOrEmpty(borr.borrowerEmail))
                {
                    if (string.IsNullOrEmpty(borr.coborrowerEmail))
                    {
                        msg.Body = "<p>Dear " + borr.borrowerFirstName + " " + borr.borrowerLastName + ",</p>";
                        msg.To.Add(borr.borrowerEmail);
                    }
                    else
                    {
                        msg.Body = "<p>Dear " + borr.borrowerFirstName + " " + borr.borrowerLastName + " and " + borr.coborrowerFirstName + " " + borr.coborrowerLastName + ",</p>";
                        msg.To.Add(borr.borrowerEmail);
                        msg.To.Add(borr.coborrowerEmail);
                    }
                }
                else
                {
                    TempData["errmsg"] = "There was an issue retrieving the loan borrower information.  Please make sure the loan number is correct. Loan Number: " + loannumber;
                    //return RedirectToAction("FileMgr", "Home", new { user = user });
                    return RedirectToAction("Index");
                }
                msg.Body = "<p>Please upload the required documents at " + link + "</p>Click the Upload button and either drag the file to the box or click Select Files.  Once uploaded click Done.";

                SmtpClient client = new SmtpClient();
                client.Host = "outbound.novahomeloans.com";
                client.Port = 25;
                client.Send(msg);
                client.Dispose();

                TempData["errmsg"] = "The email was sent successfully.";
                return RedirectToAction("Index");
                //return RedirectToAction("FileMgr", "Home", new { user = user });

            }
            catch (Exception ex)
            {
                _log.Error("Error in FileManagerData.SendLink: " + ex.Message);
                TempData["errmsg"] = "There was an error sending the email.  Please try again.";
                return RedirectToAction("Index");
                //return RedirectToAction("FileMgr", "Home", new { user = user });
            }
        }

        private static Borrower getLoanInfo(string loanNbr)
        {
            try
            {
                string accessToken = getAccessToken();

                var client = new RestClient("https://api.elliemae.com/encompass/v1/loanPipeline?cursortype=randomAccess&limit=10");
                var request = new RestRequest();
                request.Method = Method.Post;
                request.AddHeader("Authorization", "Bearer " + accessToken);
                request.AddHeader("Content-Type", "application/json");
                var body = "{\"filter\": { \"terms\": [{ \"canonicalName\": \"Loan.LoanNumber\",\"value\": \"" + loanNbr + "\",\"matchType\":\"exact\" }] }, \"fields\": [ \"Loan.LoanNumber\",\"Fields.4000\",\"Fields.4002\",\"Fields.4004\",\"Fields.4006\",\"Fields.1240\",\"Fields.1268\",\"Fields.URLA.X73\",\"Fields.URLA.X75\",\"Fields.12\",\"Fields.14\",\"Fields.15\" ] }";
                request.AddStringBody(body, DataFormat.Json);
                //RestResponse response = await client.ExecuteAsync(request);
                RestResponse response = client.Execute(request);
                var res = response.Content;

                Borrower borr = new Borrower();

                string[] data = res.Split(',');
                for (int x = 2; x < data.Length; x++)
                {
                    string[] loaninfo = data[x].Split(':');
                    switch (x)
                    {
                        case 2:
                            borr.borrowerFirstName = loaninfo[1].Replace("\"", "");
                            break;
                        case 3:
                            borr.borrowerLastName = loaninfo[1].Replace("\"", "");
                            break;
                        case 4:
                            borr.coborrowerFirstName = loaninfo[1].Replace("\"", "");
                            break;
                        case 5:
                            borr.coborrowerLastName = loaninfo[1].Replace("\"", "");
                            break;
                        case 6:
                            borr.borrowerEmail = loaninfo[1].Replace("\"", "");
                            break;
                        case 7:
                            borr.coborrowerEmail = loaninfo[1].Replace("\"", "");
                            break;
                    }
                }

                return borr;
            }
            catch (Exception ex)
            {
                _log.Error("Error in FileManagerData.getLoanInfo: " + ex.Message);
                return null;
            }
        }

        private static string getAccessToken()
        {
            try
            {
                string username = ConfigurationManager.AppSettings["userName"].ToString();
                string pass = ConfigurationManager.AppSettings["password"].ToString();
                string apiClientId = ConfigurationManager.AppSettings["apiClientId"].ToString();
                string clientSecret = ConfigurationManager.AppSettings["clientSecret"].ToString();

                var client = new RestClient("https://api.elliemae.com/oauth2/v1/token");
                //client.Timeout = -1;
                var request = new RestRequest();
                request.Method = Method.Post;
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddParameter("grant_type", "password");
                request.AddParameter("username", username);
                request.AddParameter("password", pass);
                request.AddParameter("client_id", apiClientId);
                request.AddParameter("client_secret", clientSecret);
                RestResponse response = client.Execute(request);
                string[] res = response.Content.Split(',');
                string accessToken = res[0].Substring(res[0].IndexOf(':') + 1).Replace("\"", "");

                _log.Info("Your access token is: " + accessToken);

                return accessToken;

            }
            catch (Exception ex)
            {
                _log.Error("Error in encompassData.getAccessToken: " + ex.Message);
                return null;
            }
        }
    }

    public class FileContentBrowser
    {
        public IEnumerable<FileManagerEntry> GetFiles(BlobContainerClient container, string prefix)
        {
            List<FileManagerEntry> fileManagers = new List<FileManagerEntry>();

            try
            {

                List<string> lstPrefix = new List<string>();

                // Call the listing operation and return pages of the specified size.
                var resultSegment = container.GetBlobsByHierarchy(prefix: prefix, delimiter: "/");

                // Enumerate the blobs returned for each page.
                foreach (BlobHierarchyItem blobhierarchyItem in resultSegment)
                {
                    FileManagerEntry fme = new FileManagerEntry();

                    if (!blobhierarchyItem.IsPrefix)
                    {
                        fme.IsDirectory = false;
                        fme.HasDirectories = false;
                        fme.Size = long.Parse(blobhierarchyItem.Blob.Properties.ContentLength.ToString());
                        if (string.IsNullOrEmpty(prefix))
                        {
                            fme.Name = blobhierarchyItem.Blob.Name.Substring(0, blobhierarchyItem.Blob.Name.IndexOf('.'));
                        }
                        else
                        {
                            fme.Name = blobhierarchyItem.Blob.Name.Replace(prefix, "").Substring(0, blobhierarchyItem.Blob.Name.Replace(prefix, "").IndexOf('.'));
                        }
                        fme.Path = blobhierarchyItem.Blob.Name;
                        fme.Created = DateTime.Parse(blobhierarchyItem.Blob.Properties.CreatedOn.ToString());
                        fme.Modified = DateTime.Parse(blobhierarchyItem.Blob.Properties.LastModified.ToString());
                        fme.Extension = blobhierarchyItem.Blob.Name.Substring(blobhierarchyItem.Blob.Name.IndexOf('.') + 1);
                        fileManagers.Add(fme);
                    }
                }

                return fileManagers.ToArray();
            }
            catch (RequestFailedException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public IEnumerable<FileManagerEntry> GetDirectories(BlobContainerClient container, string prefix)
        {
            List<FileManagerEntry> fileManagers = new List<FileManagerEntry>();

            try
            {

                List<string> lstPrefix = new List<string>();

                // Call the listing operation and return pages of the specified size.
                var resultSegment = container.GetBlobsByHierarchy(prefix: prefix, delimiter: "/");

                // Enumerate the blobs returned for each page.
                foreach (BlobHierarchyItem blobhierarchyItem in resultSegment)
                {
                    FileManagerEntry fme = new FileManagerEntry();

                    if (blobhierarchyItem.IsPrefix)
                    {
                        fme.IsDirectory = true;
                        fme.Name = blobhierarchyItem.Prefix.Replace("/", "");
                        fme.HasDirectories = false;
                        fme.Extension = "";
                        fme.Path = blobhierarchyItem.Prefix;
                        fileManagers.Add(fme);
                    }
                }
            }
            catch (RequestFailedException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
            return fileManagers;
        }

        public FileManagerEntry GetDirectory(string path)
        {
            var directory = new DirectoryInfo(path);

            return new FileManagerEntry
            {
                Name = directory.Name,
                Path = directory.FullName,
                Extension = directory.Extension,
                IsDirectory = true,
                HasDirectories = directory.GetDirectories().Length > 0,
                Created = directory.CreationTime,
                CreatedUtc = directory.CreationTimeUtc,
                Modified = directory.LastWriteTime,
                ModifiedUtc = directory.LastWriteTimeUtc
            };
        }

        public FileManagerEntry GetFile(string path)
        {
            var file = new FileInfo(path);

            return new FileManagerEntry
            {
                Name = Path.GetFileNameWithoutExtension(file.Name),
                Path = file.FullName,
                Size = file.Length,
                Extension = file.Extension,
                IsDirectory = false,
                HasDirectories = false,
                Created = file.CreationTime,
                CreatedUtc = file.CreationTimeUtc,
                Modified = file.LastWriteTime,
                ModifiedUtc = file.LastWriteTimeUtc
            };
        }

        public HttpServerUtilityBase Server
        {
            get;
            set;
        }
    }

}