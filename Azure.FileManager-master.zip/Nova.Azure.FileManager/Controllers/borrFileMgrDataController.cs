﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Azure;
using Kendo.Mvc.UI;
using Nova.Azure.FileManager.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using Microsoft.Ajax.Utilities;
using System.Runtime.InteropServices.ComTypes;
using System.Net.Mail;
using System.Configuration;
using RestSharp;

namespace Nova.Azure.FileManager.Controllers
{
    public class borrFileMgrDataController : Controller
    {
        private readonly FileContentBrowser directoryBrowser;
        public static IEnumerable<FileManagerEntry> fMgrEntries = new List<FileManagerEntry>();
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        // GET: borrFileMgrData

        public borrFileMgrDataController()
        {
            // Helper utility for the FileManager controller
            directoryBrowser = new FileContentBrowser();
        }

        [AllowAnonymous]
        public ActionResult borrIndex(string loanNbr, string LO)
        {
            borrClient user = new borrClient();
            user.loanNbr = loanNbr;
            user.LO = LO;

            setCookie(user);

            return View(user);
        }

        private string ToAbsolute(string virtualPath)
        {
            return VirtualPathUtility.ToAbsolute(virtualPath);
        }

        public string ContentPath
        {
            get
            {
                return "~/";
            }
        }

        private string CombinePaths(string basePath, string relativePath)
        {
            return VirtualPathUtility.Combine(VirtualPathUtility.AppendTrailingSlash(basePath), relativePath);
        }

        public string NormalizePath(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return ToAbsolute(ContentPath);
            }

            return CombinePaths(ToAbsolute(ContentPath), path);
        }

        public FileManagerEntry VirtualizePath(FileManagerEntry entry)
        {
            entry.Path = entry.Path.Replace(Server.MapPath(ContentPath), "").Replace(@"\", "/");
            return entry;
        }

        [HttpPost]
        public JsonResult Read(string target)
        {
            borrClient user = getCookie();
            var path = NormalizePath(target);
            string blobContainer = string.Empty;

            try
            {
                blobContainer = user.LO;
                target = user.loanNbr + "/";

                string blobCon = "blobconnectionstring";
                BlobServiceClient bSC = new BlobServiceClient(blobCon);

                var container = bSC.GetBlobContainerClient(blobContainer);

                if (!container.Exists())
                {
                    bSC.CreateBlobContainer(blobContainer);
                }

                List<FileManagerEntry> fmes = new List<FileManagerEntry>();
                directoryBrowser.Server = Server;

                var result = directoryBrowser.GetFiles(container, target).Select(VirtualizePath);
                return Json(result, JsonRequestBehavior.AllowGet);
            } catch (Exception ex)
            {
                _log.Error("Error in borrFileMgrData.Read: " + ex.Message);
                return Json(null, JsonRequestBehavior.AllowGet);
            }

        }
        public ActionResult borrHelp()
        {
            borrClient user = getCookie();
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Upload(string path, HttpPostedFileBase file)
        {
            borrClient user = getCookie();
            //FileManagerEntry newEntry;
            string blobContainer = string.Empty;

            try
            {
                path = user.loanNbr + "/";
                blobContainer = user.LO;

                path = NormalizePath(path);
                var fileName = Path.GetFileName(file.FileName);

                if (!string.IsNullOrEmpty(path))
                {
                    fileName = path + fileName;
                }

                string blobCon = "blobconnectionstring";
                BlobServiceClient bSC = new BlobServiceClient(blobCon);

                var container = bSC.GetBlobContainerClient(blobContainer);
                BlobClient blobClient = container.GetBlobClient(fileName);

                blobClient.Upload(file.InputStream, true);

                var result = directoryBrowser.GetFiles(container, null).Select(VirtualizePath);
                return Json(result, JsonRequestBehavior.AllowGet);
            } catch (Exception ex)
            {
                _log.Error("Error in borrFileMgrData.Upload: " + ex.Message);
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            //throw new HttpException(403, "Forbidden");
        }

        private void setCookie(borrClient cuser)
        {
            HttpContext.Response.Cookies.Remove("fMgr");
            DateTime exp = DateTime.Today.AddDays(1);
            HttpCookie cookie = new HttpCookie("fMgr");
            cookie.Values.Set("loanNbr", cuser.loanNbr);
            cookie.Values.Set("LO", cuser.LO);
            HttpContext.Response.Cookies.Set(cookie);
        }

        private borrClient getCookie()
        {
            try
            {
                HttpCookie cookie = Request.Cookies["fMgr"];
                if (cookie != null)
                {
                    borrClient cuser = new borrClient();
                    cuser.loanNbr = cookie["loanNbr"];
                    cuser.LO = cookie["LO"];
                    return cuser;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error in Home.getCookie: " + ex.Message);
                return null;
            }
        }

    }

}