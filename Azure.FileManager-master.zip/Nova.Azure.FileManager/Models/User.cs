﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Nova.Azure.FileManager.Models
{
    public class cUser
    {
        [Key]
        [DisplayName("User ID")]
        public string UserID { get; set; }
        [DisplayName("User Name")]
        public string UserName { get; set; }
        [DisplayName("User Email")]
        public string UserEmail { get; set; }
        public string DispayName { get; set; }
        public string UserRole { get; set; }
    }

    public class Borrower
    {
        public string borrowerFirstName { get; set; }
        public string borrowerLastName { get; set; }
        public string borrowerEmail { get; set; }
        public string coborrowerFirstName { get; set; }
        public string coborrowerLastName { get; set; }
        public string coborrowerEmail { get; set; }
    }

    public class borrClient
    {
        public string loanNbr { get; set; }
        public string LO { get; set; }
    }
}